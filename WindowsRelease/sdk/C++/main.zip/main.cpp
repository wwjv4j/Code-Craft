#include <bits/stdc++.h>
using namespace std;

const int n = 200;
const int robot_num = 10;
const int berth_num = 10;
const int N = 210;
const double weight = 0.5;
const int aim_berth = 9;
struct Robot
{
    int x, y, goods;
    int status;
    int mbx, mby;
    bool on_road; //机器人是否正在前往的路上
    bool stuck; //机器人是否被困住
    vector<int> move_order;//机器人的运行指令
    Robot() {stuck = 0;}
    Robot(int startX, int startY) {
        x = startX;
        y = startY;
        on_road = false;
    }
}robot[robot_num + 10];

struct Berth
{
    int x;
    int y;
    int transport_time;
    int loading_speed;
    int goods_num;//泊口货物数量
    Berth(){}
    Berth(int x, int y, int transport_time, int loading_speed) {
        this -> x = x;
        this -> y = y;
        this -> transport_time = transport_time;
        this -> loading_speed = loading_speed;
        this -> goods_num = 0;
    }
}berth[berth_num + 10];

struct Goods
{
    int id, x, y, val; //货物出现帧数，地址，价值
    Goods(){
        id = 0;
        x = 0;
        y = 0;
        val = 0;
    }
    Goods(int id, int x, int y, int val){
        this->id = id;
        this->x = x;
        this->y = y;
        this->val = val;
    }
};

struct Boat
{
    int num, pos, status;
    int remain_capacity;//增加船剩余容量
}boat[10];

struct Point
{
    int x, y, priority;
    Point(){}
    Point(int x, int y, int p){
        this->x = x;
        this->y = y;
        this->priority = p;
    }
   bool operator< (const Point &a)const{
    return priority > a.priority;
   }
};

int money, boat_capacity, id;
char ch[N][N];
int gds[N][N];
// int mp[N][N];
int direction[4][2] = {0, 1, 0, -1, -1, 0, 1, 0};
vector<Goods> goods;

void Init()
{
    for(int i = 0; i < n; i ++)
        scanf("%s", ch[i]);
    // for(int i = 0; i < n; i ++)
    //     for(int j = 0; j < n; j++)
    //         if(ch[i][j] == '.' || ch[i][j] == 'B' || ch[i][j] == 'A')
    //             mp[i][j] = 1;
    for(int i = 0; i < berth_num; i ++)
    {
        int id;
        scanf("%d", &id);
        scanf("%d%d%d%d", &berth[id].x, &berth[id].y, &berth[id].transport_time, &berth[id].loading_speed);
    }
    scanf("%d", &boat_capacity);
    for(int i = 0;i<5;i++)
    boat[i].remain_capacity = boat_capacity;
    char okk[100];
    scanf("%s", okk);
    printf("OK\n");
    fflush(stdout);
}

int Input()
{
    scanf("%d%d", &id, &money);
    int num;
    scanf("%d", &num);
    for(int i = 1; i <= num; i ++)
    {
        int x, y, val;
        scanf("%d%d%d", &x, &y, &val);
        
        goods.push_back(Goods(id, x, y, val));
        gds[x][y] = 1;
    }
    for(int i = 0; i < robot_num; i ++)
    {
        int sts;
        scanf("%d%d%d%d", &robot[i].goods, &robot[i].x, &robot[i].y, &robot[i].status);
    }
    for(int i = 0; i < 5; i ++)
        scanf("%d%d\n", &boat[i].status, &boat[i].pos);
    char okk[100];
    scanf("%s", okk);
    return id;
}


vector<int > find_road(int x1, int x2, int x3, int x4);//计算两点之间距离
int heuristic(int x, int y, int x2, int y2);
void RobotCmd();
void Move(int robot_id);
void ShipCmd();
void ChooseGoods(int robot_id);
void Del_Goods();
void Test();
void find_goods(int robot_id);
int Get_Goods_id(int x, int y);
void Robot_Init(int id);
void Wall_Check(int i);
void CheckCollision(int i);

int main()
{
    Init();
    for(int zhen = 1; zhen <= 15000; zhen ++)
    {
        int id = Input();
        if(id <= 10)
        {
            Robot_Init(id-1);
        }
        else
        {
            Del_Goods();
            RobotCmd();
            ShipCmd();
            // Test();
        }
        puts("OK");
        fflush(stdout);
    }

    return 0;
}
/*
void Test()
{
    Robot& rob = robot[0];
    Berth& ber = berth[0];
    if(rob.x == ber.x && rob.y == ber.y)
        return;
    if(rob.move_order.size() > 0)
    {
        Move(0);
    }
    else
    {
        rob.move_order = find_road(rob.x,rob.y,ber.x,ber.y);
        ofstream ofs;
        ofs.open("path.txt",ios::out);
        ofs<<rob.x <<" "<<rob.y<<" "<<ber.x<<" "<<ber.y<< " "<< find_road(rob.x,rob.y,ber.x,ber.y).size() <<endl;
        for(int i=rob.move_order.size()-1;i>=0;i--)
        {
            ofs<<rob.move_order[i]<<" ";
        }
        ofs.close();
    }
    

}
*/
//一帧中机器人的指令
void RobotCmd()
{
    for(int i = 0;i<10;i++)
    {   
        // if(!robot[i].status)
        // {
        //     robot[i].move_order.push_back(-1);
        // }
        if(!robot[i].status || robot[i].stuck) 
            continue;
        if(robot[i].on_road)
        {
            //如果还没走完，按之前计算出的路径继续走
            if(robot[i].move_order.size())
            {
                Wall_Check(i);
                CheckCollision(i);
                Move(i);
            }
            //如果已经到达了目的地
            else
            {
                //如果到达了货物，就进行泊口路径规划
                //如果当前坐标有货物
                if(gds[robot[i].x][robot[i].y])
                {
                    printf("get %d\n",i);
                    gds[robot[i].x][robot[i].y] = 0;
                    // robot[i].move_order = find_road(robot[i].x,robot[i].y,berth[0].x,berth[0].y);
                    robot[i].move_order = find_road(robot[i].x,robot[i].y,berth[aim_berth].x,berth[aim_berth].y);
                    if(robot[i].move_order.size() == 0)robot[i].stuck = 1;
                    robot[i].mbx = berth[aim_berth].x;robot[i].mby = berth[aim_berth].y;
                    CheckCollision(i);
                    Move(i);
                    continue;
                }

                if(ch[robot[i].x][robot[i].y] == 'B')
                {
                    //否则到达了泊口，重新进行货物路径规划
                    printf("pull %d\n",i);
                    berth[aim_berth].goods_num ++;
                    ChooseGoods(i);
                    CheckCollision(i);
                    Move(i);
                    continue;
                }
                if(robot[i].goods)
                {
                    //如果机器人手上有货物但是没有路径
                    robot[i].move_order = find_road(robot[i].x,robot[i].y,berth[aim_berth].x,berth[aim_berth].y);
                    robot[i].mbx = berth[aim_berth].x;robot[i].mby = berth[aim_berth].y;
                    CheckCollision(i);
                    Move(i);
                }
                else
                {
                    //如果机器人没货没路径
                    ChooseGoods(i);
                    CheckCollision(i);
                    Move(i);
                }

            }
                
        }

        else
        {
            ChooseGoods(i);
            CheckCollision(i);
            Move(i);
        }
        
    }
}

//机器人按照路径移动
void Move(int robot_id)
{
    if(robot[robot_id].move_order.empty()) 
        return; 
    int dir = robot[robot_id].move_order.back();
    if(dir == -1){robot[robot_id].move_order.pop_back();return;}
    robot[robot_id].move_order.pop_back();
    printf("move %d %d\n",robot_id,dir);
}

void ChooseGoods(int robot_id)
{
    int x = robot[robot_id].x, y = robot[robot_id].y;
    int i = goods.size()-1;
    while(i>=0)
    {
        // if(j>10)break;
        // j++;
        vector<int >path = find_road(x,y,goods[i].x,goods[i].y);//货物路径
        if(id - goods[i].id + path.size() < 1000)
        {
            robot[robot_id].mbx = goods[i].x;robot[robot_id].mby = goods[i].y;
            robot[robot_id].move_order = path;
            goods.erase(goods.begin()+i);
            robot[robot_id].on_road = true;
            return;
        }
        i--;
    }
    // 对每个机器人，对货物计算距离和价值的加权值，选择最优
    // struct Val{
    //         int goods_id;
    //         int path_length;
    //         int goods_value;
    //         double true_value;
    //         Val(int pl,int val,int gdid){
    //             goods_id = gdid;
    //             path_length = pl;
    //             goods_value = val;
    //             true_value = -path_length  * weight + goods_value * 0.1 * (1-weight);
    //         }
    //         bool operator<(const Val& b){return this->true_value<b.true_value;}
    // };
    // for(int i=0;i<10;i++)
    // {
    //     priority_queue<Val> possible_goods;
    //     for(int j=0;j<goods.size();j++)
    //     {
    //         robot[robot_id].move_order = find_road(x,y,goods[j].x,goods[j].y);
    //         possible_goods.push(Val(robot[robot_id].move_order.size(),goods[j].val,j));
    //     }
    //     auto g = possible_goods.top();
    //     robot[robot_id].move_order = find_road(x,y,goods[g.goods_id].x,goods[g.goods_id].y);
    //     goods.erase(goods.begin()+g.goods_id);
    // }
}

void Del_Goods()
{
    for(int i = ((int)(goods.size()-1) > 11)?11:(goods.size()-1);i>=0;i--){
        if(id - goods[i].id > 1000)
        {
            gds[goods[i].x][goods[i].y] = 0;
            goods.erase(goods.begin()+i);
        }
    }
}

void ShipCmd()
{
    for(int i = 0;i<5;i++){
        if(boat[i].status == 1 && boat[i].pos >=0){//如果处于正常运行状态
            int get_goods = min(boat[i].remain_capacity, min(berth[aim_berth].goods_num, berth[aim_berth].loading_speed));
            boat[i].remain_capacity -= get_goods;//取货
            berth[0].goods_num -= get_goods;
            if(id %1000 == 0)//判断容量是否为0
            {
                printf("go %d\n", i);
                boat[i].remain_capacity = boat_capacity;
            }
        }
        else if(boat[i].status == 2){//等待状态
            printf("ship %d %d\n", i, aim_berth);
        }
        else if(boat[i].status == 1 && boat[i].pos == -1){
            printf("ship %d %d\n", i, aim_berth);
        }
    }
}

//find_road()//计算两点之间距离
vector<int > find_road(int x1, int y1, int x2, int y2)//计算两点之间距离
{
    Point c_point;
    priority_queue<Point > priority;
    vector<int > ans;
    if(x1 == x2 && y1 == y2)return ans;
    int sign[205][205][2];//记录当前点到起点的距离和上一步的方向
    for(int i = 0;i<n;i++)
    for(int j = 0;j<n;j++)
    {sign[i][j][1] = 0;sign[i][j][0] = -1;}
    priority.push(Point(x1, y1, 0));
    sign[x1][y1][0] = 0;
    sign[x1][y1][1] = -1;

    while(!priority.empty()){
        int x, y, x_d, y_d;
        c_point = priority.top();
        priority.pop();
        x = c_point.x;y = c_point.y;

        for(int i = 0;i<4;i++){
            x_d = x+direction[i][0];y_d = y+direction[i][1];
            if((ch[x_d][y_d] == '.' || ch[x_d][y_d] == 'B' || ch[x_d][y_d] == 'A') && sign[x_d][y_d][0] == -1){
                sign[x_d][y_d][0] = sign[x][y][0] + 1;
                sign[x_d][y_d][1] = i;
                priority.push(Point(x_d, y_d, sign[x_d][y_d][0] + heuristic(x_d, y_d, x2, y2)));
            }
            if(x_d == x2 && y_d == y2){ //是否到达终点
                int step = sign[x2][y2][1];
                x = x_d;y = y_d;
                while(step != -1){
                    ans.push_back(step);
                    x -= direction[step][0];y -= direction[step][1];
                    step = sign[x][y][1];
                }
                //reverse(ans.begin(), ans.end());
                return ans;
            }
        }
    }
    return ans;
}

// void find_goods(int robot_id)
// {
//     Point c_point;
//     queue<Point > BFS;
//     vector<int > ans;
//     int x, y;
//     //if(gds[robot[robot_id].x][robot[robot_id].y])return ans;
//     int sign[205][205][2];//记录当前点的距离和上一步的方向
//     for(int i = 0;i<n;i++)
//     for(int j = 0;j<n;j++)
//     {sign[i][j][1] = 0;sign[i][j][0] = 0;}
//     BFS.push(Point(robot[robot_id].x, robot[robot_id].y, 0));
//     sign[robot[robot_id].x][robot[robot_id].y][0] = 1;
//     sign[robot[robot_id].x][robot[robot_id].y][1] = -1;
//     while(!BFS.empty())
//     {
//         int x_d, y_d;
//         c_point = BFS.front();
//         BFS.pop();
//         x = c_point.x;y = c_point.y;
//         if(gds[x][y] == 1 && (1000 - id + goods[Get_Goods_id(x , y)].id >= c_point.priority))//如果找到货物
//         {
//             int step = sign[x][y][1];
//             while(step != -1){
//                 ans.push_back(step);
//                 x -= direction[step][0];y -= direction[step][1];
//                 step = sign[x][y][1];
//             }
//             robot[robot_id].move_order = ans;
//             return;
//             //reverse(ans.begin(), ans.end());
//         }
//         for(int i = 0;i<4;i++)
//         {
//             x_d = x+direction[i][0];y_d = y+direction[i][1];
//             if((ch[x_d][y_d] == '.' || ch[x_d][y_d] == 'B' || ch[x_d][y_d] == 'A') && sign[x_d][y_d][0] == 0)//如果该点可以移动且没有访问，则加入队列
//             {
//                 BFS.push(Point(x_d, y_d, c_point.priority+1));
//                 sign[x_d][y_d][0] = 1;
//                 sign[x_d][y_d][1] = i;
//             }
//         }
//     }
//     robot[robot_id].move_order = ans;
// }

int Get_Goods_id(int x, int y)//获取指定坐标货物在向量中的位置
{
    for(int i = 0;i<goods.size();i++)
    {
        if(goods[i].x == x && goods[i].y == y)
        {
            return goods[i].id;
        }
    }
    return 0;
}
int heuristic(int x, int y, int x2, int y2){//代价估计函数
    return abs(x2-x) + abs(y2-y);
}

void Robot_Init(int p_id)//机器人分批启动
{
    ChooseGoods(p_id);
    CheckCollision(p_id);
    Move(p_id);
}

void Wall_Check(int i)//撞墙监测
{
    int next_step = robot[i].move_order.back();
    int x = robot[i].x + direction[next_step][0], y = robot[i].y + direction[next_step][1];
    if(ch[x][y] != '.' || ch[x][y] != 'B' || ch[x][y] != 'A')//如果下一步是墙
    {
        robot[i].move_order = find_road(robot[i].x, robot[i].y, robot[i].mbx, robot[i].mby);
    }
    return;
}

void CheckCollision(int i)
{
    if(robot[i].move_order.size() == 0)return;
    int mp[N][N] = {0};
    int next_step;
    int x, y, x_d, y_d;
    for(int j = 0;j<10;j++)
    {   
        if(robot[j].move_order.size())
        {
            next_step = robot[j].move_order.back();
            x = robot[j].x;y = robot[j].y;
            mp[x][y]++;
            if(next_step != -1)
            {
                x = robot[j].x + direction[next_step][0], y = robot[j].y + direction[next_step][1];
                mp[x][y]++;
            }
        }
    }
    next_step = robot[i].move_order.back();
    x = robot[i].x + direction[next_step][0], y = robot[i].y + direction[next_step][1];
    if(mp[x][y] > 1)//如果存在一个以上机器人在同一个位置
    {
        x = robot[i].x;y = robot[i].y;
        for(int j = 3;j >= 0; j--)
        {
            x_d = x + direction[j][0];y_d = y + direction[j][1];
            if(mp[x_d][y_d] == 0 && (ch[x_d][y_d] != '.' || ch[x_d][y_d] != 'B' || ch[x_d][y_d] != 'A'))
            {
                // robot[i].move_order.push_back(j^1);
                robot[i].move_order.push_back(j);
                return;
            }
        }
        robot[i].move_order.push_back(-1);
    }
}

//记录船还有多久回泊口

//选择泊口

//这个坐标有没有用

//碰撞监测和优化

//价值，时间，速度

/*
1.1 增加泊口当前货物数量，增加船只当前剩余容量，增加Goods类，使用数组存储出现的货物（可考虑使用优先队列）
*/
